//***************************************************************
//	List.cpp						*
//	Source codes of list and queue.				*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "list.h"
/* Object : _list */
void _list ::insert(_node *node)
{
	if( is_empty()	){	//	list is empty
		_head = node;
		_focus = node;
		node->prev(node);
		node->next(node);
	}
	else{
		node->prev(_focus->prev());
		node->next(_focus);
		(_focus->prev())->next(node);
		_focus->prev(node);
	}
}

_node *_list :: erase()
{_node *node;
	if( is_empty() )	// list empty
		return NULL;
	else if ( _head->next() == _head ){	// only one node
		node = _focus;
		_head = _focus = NULL;
		return node;
	}
	else{
		node = _focus;
		(_focus->prev())->next( _focus->next() );
		(_focus->next())->prev( _focus->prev() );
		_focus = node->next();
		node->prev(NULL);
		node->next(NULL);
		if( node == _head )	chgHead(_focus); // if head node is removed
		return (node);
	}
}

int _list :: operator >> (int i)
{
	if( is_empty() )	return	0;
	for(int j=i ; j>0 ; j--)		// move focus to next i items
		_focus = _focus->next();
	if( _focus == _head )	return 0;
	return 1;
}

int _list :: operator << (int i)
{
	if( is_empty() )	return 0;
	for(int j=i ; j<0 ; j--)		// move focus to previous i items
		_focus = _focus->prev();
	if( _focus == _head )	return 0;
	return 1;
}

/* Object : _queue */

void _queue :: operator + ( _qItem *item )
{
	if( _list :: is_empty() )	_list :: insert( (_node *) item );
	else{
		_qItem *f = (_qItem*)toHead();
		while( f->priority() <= item->priority() ){ // search priority
			if( (_list :: operator >> (1)) == 0 )	break;
				f = (_qItem*)_list :: focus();
		}
		_list::insert((_node*) item );	// insert it !
		if( item->priority() < first()->priority() )
			_list :: chgHead(item);	// if new item's priority is highest
	}
}

_qItem * _queue :: operator -- ()
{
	if( _list :: is_empty() )	return NULL;
	_list :: toHead();
	return (_qItem *) _list :: erase () ; // remove first item, and return
}

/*
class StrItem : _qItem{
 private:
	char *_string;
 public:
	void string(char *s)
	{	_qItem :: priority( s[0] );
		_string = s;
	}
	char * string()		{	return _string;	}
};
class StringQ : public _queue{
 public:
	void operator+(char *s);
	char * operator --();
};
void StringQ :: operator + (char *s)
{
 StrItem *item = new StrItem;
	item->string( s );
	_queue :: operator + ( (_qItem *) item );
}

char * StringQ :: operator --()
{
	StrItem * item;
	char *s;
		item = (StrItem *) _queue :: operator -- ();
		s = item->string();
		delete item;
		return s;
}

//#include "c:\bin\TC\classlib\include\timer.h"
#include <iostream.h>
void main()
{
 StringQ	Q;
// Timer timer;
	Q+"This";
	Q+"Is";
	Q+"A";
	Q+"Test";
	Q+",";
	Q+"And";
	Q+"It";
	Q+"Should";
	Q+"Be";
	Q+"Right";
	cout << " Origin : This Is A Test , And It Should Be Right\n";
	cout << " Sorted : \n";
	char *string;
	do{
//		timer.start();
		string = --Q;
//		timer.stop();
		cout << string <<"\n";
//		timer.reset();
	}while( !Q.is_empty() );
//	cout << "\nTime used : "<< timer.time();
}
*/