//***************************************************************
//	Taskmgr.cpp						*
//	Definitions of task manager.				*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "kernel.h"
#include "taskmgr.h"
#include <malloc.h>
APIRET far TaskMGR :: CreateTimeTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio,unsigned period)
{
 Thread *thread=NULL;
 void far *stack=NULL;
	Tau.DispatchMask = 1;
	thread = (Thread*)farmalloc(sizeof(Thread));
	stack = farmalloc(stack_size);
	Tau.DispatchMask = 0;
	if( (thread == NULL) || (stack == NULL) )	return ERR_NOSPACE;
	thread->setup(proc,arg,stack,stack_size,prio,
									THREAD_TIMECRITICAL,period,EndTask);
	APIRET rc = Tau.CreateThread(thread);
	id = thread->tid;
	return rc;
}

APIRET far TaskMGR :: CreateEventTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio)
{
 Thread *thread=NULL;
 void far *stack=NULL;
	Tau.DispatchMask = 1;
	thread = (Thread*)farmalloc(sizeof(Thread));
	stack = farmalloc(stack_size);
	Tau.DispatchMask = 0;
	if( (thread == NULL) || (stack == NULL) )	return ERR_NOSPACE;
	thread->setup(proc,arg,stack,stack_size,prio,THREAD_EVENTDRIVEN,0,EndTask);
	APIRET rc = Tau.CreateThread(thread);
	id = thread->tid;
	return rc;
}

APIRET far TaskMGR :: CreateSliceTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio)
{
 Thread *thread=NULL;
 void far *stack=NULL;
	Tau.DispatchMask = 1;
	thread = (Thread*)farmalloc(sizeof(Thread));
	stack = farmalloc(stack_size);
	Tau.DispatchMask = 0;
	if( (thread == NULL) || (stack == NULL) )	return ERR_NOSPACE;
	thread->setup(proc,arg,stack,stack_size,prio,THREAD_TIMESLICING,0,EndTask);
	APIRET rc = Tau.CreateThread(thread);
	id = thread->tid;
	return rc;
}

APIRET far TaskMGR :: KillTask(unsigned id)
{
 Thread *thread;
	if( id == Tau.CurrentThreadID() )	return ERR_BADID;
	Tau.SuspendThread(id);
	APIRET rc = Tau.KillThread(id);
	Tau.DispatchMask = 0;
	return rc;
}

APIRET far TaskMGR :: SuspendTask(unsigned id)
{
 unsigned tid = Tau.CurrentThreadID();
	APIRET rc = Tau.SuspendThread(id);
	if( id == tid ){	SWITCH_CONTEXT;}
	return rc;
}

APIRET far TaskMGR :: ResumeTask(unsigned id)
{
	APIRET rc = Tau.ResumeThread(id);
	SWITCH_CONTEXT;
	return rc;
}

void far EndTask()
{
	Tau.SuspendThread(Tau.CurrentThreadID());
	Tau.KillThread(Tau.CurrentThreadID());
	SWITCH_CONTEXT;
}

