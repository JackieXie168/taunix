//***************************************************************
//	Comm.cpp						*
//	Definition of communication facilities.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "comm.h"

mbox :: ~mbox()
{_node *n;
        n = _list :: toHead();
        MaskDispatcher;
	   while(! _list :: is_empty() ){
			 n = _list :: focus();
			 delete n;               //release message in mbox
			 _list :: operator>>(1);
	   }
	   ReleaseDispatcher;
}
void mbox :: put(MSGPack *mpack)
{
	Tau.DispatchMask = 1;
	_list :: insert((_node*)mpack); // insert new message
	Tau.DispatchMask = 0;
}
MSGPack far * mbox :: get()
{MSGPack far *mpack=NULL;

	if( !_list :: is_empty() ){
		Tau.DispatchMask = 1;
		// get MSGPack
		mpack = (MSGPack far *)_list :: erase();
		Tau.DispatchMask = 0;
	}
	// if no message, return NULL
	return mpack;
}


PORT :: PORT()
{
	   // Task ID is set in the priority of PORT
	   _qItem::priority(Tau.CurrentThreadID());
	   // registration automaticlly
	   COMM.RegisterPort(this);
}
PORT :: ~PORT()
{
	   // cancel registration
	   COMM.DeletePort();
}

int PORT :: PutMessage(MSGPack *mpack)
{
	   mail_list.put(mpack); // put MSGPack in
	   if(inWait)	msg.post();
	   return ERR_NOERROR;
}

int PORT :: hasMSG()    // test if there is any msg in port
{
	   if(mail_list.is_empty())        return 0;
	   else                            return 1;
}

MSGPack * PORT :: GetMessage(int time_out)
{MSGPack *p;
	   if( mail_list.is_empty() ){
			inWait=1;
			msg.pend(time_out);
	   }
	   p = mail_list.get();    // get MSGPack, if no message, return NULL
	   inWait = 0;
	   return p;
}

void COMMGR :: RegisterPort(PORT *p)
{
	   MaskDispatcher;
	   PortList + (_qItem*)p;  // add port into PortList
	   ReleaseDispatcher;
}

void COMMGR :: DeletePort()
{unsigned tid = Tau.CurrentThreadID();// PORT ID that want to be cancel
	   MaskDispatcher;
	   PortList.toHead();
	   do{
			 if( (PortList.focus())->priority() == tid ){
				    // find one, and remove it
				    PortList.remove_focus();
				    break;
			 }
	   }while(PortList>>1);
	   ReleaseDispatcher;
}

int COMMGR :: operator << (MSGPack *mpack)
{ // send message by Communication Manager

 if( PortList.is_empty() )                return ERR_BADID;
 PORT *p = (PORT*)PortList.first();
 PORT *h = p;
	   while(1){
			 if( p->priority() == mpack->Receiver){
			    // if find target PORT
				    p->PutMessage(mpack); // put message in
				    break;
			 }
			 p = (PORT*)p->next();
			 if( p == h )        return ERR_BADID;
	   }
	   return ERR_NOERROR;
}

