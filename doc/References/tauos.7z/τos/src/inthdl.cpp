//***************************************************************
//	Inthdl.cpp						*
//	Definition of interrupt handler of int 08h and int 0ffh.*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "kernel.h"

int far inCTXTSW = 0;	// To indicate if CTXTSW is in execution

void far interrupt CTXTSW(...)
{
	if( inCTXTSW )	return;	// CTXTSW is re-entered, return
	inCTXTSW = 1;
	asm	sub sp,94;	// prepare to save fpu context
	if( Tau.FpuFlag  ){	asm{// if there has fpu on your system
		mov ax,bp		// save bp in ax
		mov bp,sp		// set bp == sp
		fsave [bp]	// save fpu context in stack
		mov bp,ax		// retore bp
	}}

	if( Tau.StartFlag ){	// if kernel is just started
		Tau.StartFlag = 0;
		Tau.DispatchMask = 0;
		// save original stack pointer in TauKernel object
		Tau.SS = _SS; Tau.SP = _SP; Tau.BP = _BP;
	}
	else if( Tau.CurrentThreadType ){
		// if system is in normal execution,
		// save stack pointer in thread object
		Tau.CurrentThread[Tau.CurrentThreadType-1]->SP = _SP;
		Tau.CurrentThread[Tau.CurrentThreadType-1]->BP = _BP;
		Tau.CurrentThread[Tau.CurrentThreadType-1]->SS = _SS;
	}

	if( Tau.ShutDown ){// if shutdown, take the original context back
		asm cli;
		_SS = Tau.SS; _SP = Tau.SP; _BP = Tau.BP;
	}

	int thread_type = 0;	// for reschedule

	if( !Tau.ShutDown ){	// if not shutdown
		asm cli;
		for(int i=0 ; i<16 ; i++){ // resume time-critical thread
			if( Tau.Time[i] ){
				if( Tau.Time[i]->slice_left <= 0 ){
					Tau.ResumeThread(Tau.Time[i]->tid);
					Tau.Time[i]->slice_left = Tau.Time[i]->slice;
				}
			}
		}


		if( !Tau.TimeDelay.is_empty()){ // resume delayed thread
			Thread *delay = Tau.TimeDelay();
			Thread *head = delay;
			do{
				if( delay->slice_left <= 0 ){
					Tau.ResumeThread(delay->tid);
					break;
				}
				delay = (Thread *)delay->next();
			}while(head != delay );
		}

		Tau.DispatchMask = 0;
		// now, dispatching thread
		thread_type = Tau.TimeDispatch();
		if( !thread_type )
			thread_type = Tau.EventDispatch();
		if( !thread_type )
			thread_type = Tau.SliceDispatch();
		asm sti;
	}

	if( thread_type ){
		Tau.CurrentThreadType = thread_type;
		// tack back new thread's stack pointer
		_SP = Tau.CurrentThread[thread_type-1]->SP;
		_BP = Tau.CurrentThread[thread_type-1]->BP;
		_SS = Tau.CurrentThread[thread_type-1]->SS;
	}

	if( Tau.FpuFlag ){asm{ // restore new thread's fpu context
		mov ax,bp
		mov bp,sp
		frstor [bp]	// restore
		mov bp,ax
	}}
	asm add sp,94;		// reset SP
	inCTXTSW = 0;		// leave CTXTSW
}


void far interrupt ClockISR(...)
{
	if( Tau.TickISR ){	// if user program had ever insert a tick isr
					// in Tau.TickISR, then execute it first

		if( Tau.FpuFlag  ){	asm{// if there has fpu on your system
			sub sp,94;	// prepare to save fpu context
			mov ax,bp
			mov bp,sp
			fsave [bp]
			mov bp,ax
		}}

		Tau.TickISR();		// user tick isr

		if( Tau.FpuFlag ){asm{ // restore fpu context
			mov ax,bp
			mov bp,sp
			frstor [bp]
			mov bp,ax
			add sp,94;
		}}


	}

	for(int i=0 ; i<16 ; i++) // take care time-critical thread
		if( Tau.Time[i] )
			--Tau.Time[i]->slice_left;

	asm cli;
	if( !Tau.TimeDelay.is_empty()){ // take care time delay queue
		Thread *delay = Tau.TimeDelay();
		Thread *head = delay;
		do{
			delay->slice_left --;
			delay = (Thread *)delay->next();
			// use this method (not directly using _focus)
			// 						to prevent re-entrance
		}while(head != delay );
	}
	asm sti;

	Tau.TickCounter ++;		// increase timer counter
	asm int 0xfe;			// original PC's int 08h
	if( !(Tau.DispatchMask || inCTXTSW) )
		// if kernel is not in critical section or
		//					IntFFh is not in execution
		asm int 0xff;	// call context switch procedure
}