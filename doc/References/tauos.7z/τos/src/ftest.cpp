//***************************************************************
//	Ftest.cpp						*
//	Testing FPU types.					*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

int FPUTest()
{
	asm{
		fninit
		mov	si,0xfffe;
		sub	si,bp;
		xor dx,dx
		mov	word ptr [si+bp],0x5a5a ;// FPU needs [si+bp] addressing mode
		fnstsw [si+bp];	// test whether can read fpu's status word
		mov	ax,[si+bp];	// if can, [si+bp] will be zero
	}
	if(_AX)	return 0;	// no fpu
	asm{
		fnstcw	[bp+si];	// now read fpu's control word
		mov	ax,[bp+si];
		and		ax,0x103f;
	}	// now compare the default typd with fpu's control word
	if(!( _AX && 0x3f ))	return 0;	//no npu
	asm{	// now, it's sure that there is an FPU on system
		fld1;	// load 1
		fldz;	// load 0
		fdiv;	// 1/0 = infinity	,produce positive infinity
		fld st;	// copy to another st
		fchs;	// change it to negtive infinity
		fcompp;			// if 87/287, +inf == -inf
		fnstsw	[si+bp];  // but,387 says +inf != -inf
		mov	ax,[si+bp];
		jne	n387;
	}
	return	1;	// 8087/287
n387:
	return	2;	// 80387
}
/*
#include <iostream.h>
void main()
{
	int fpu = FPUTest();
	switch(fpu){
	 case 0:
		cout <<"There is no fpu on your system";
		break;
	 case 1:
		cout <<"I detect an 8087 or 80287 on your system";
		break;
	 case 2:
		cout <<"I detect an 80387 or higher chip on your system";
		break;
	}
}*/