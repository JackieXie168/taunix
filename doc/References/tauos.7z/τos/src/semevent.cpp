//***************************************************************
//	Semevent.cpp						*
//	Definition for SEM and EVENT objects.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "kernel.h"
#include "semevent.h"

sigItem far *findfree(sigItem far *wt,unsigned size)
{ // serach free sigItem in pool, first-fit algorithm is used
	for(int i=0 ; i<size ; i++)
		if( wt[i].id == 0 )
			return( &wt[i] );
	return NULL;
}

SIG :: SIG(unsigned size)
{
	MaskDispatcher;
	pool_size = size;
	pool = new sigItem[size];
	if(pool == NULL )	pool_size = 0;
	ReleaseDispatcher;
}
SIG :: ~SIG()
{
	MaskDispatcher;
	delete pool;
	ReleaseDispatcher;
}

int far SIG :: pend(unsigned time_out)
{
	MaskDispatcher;
	sigItem far *wt = findfree(pool,pool_size);
	if( wt == NULL )
		return ERR_SIGBUSY;
	wt->id = Tau.CurrentThreadID();	// set id
	waitL.toHead();
	waitL.insert(wt);
	if( time_out )		// if want to time_out, drop it to delay queue
		Tau.SuspendThread(wt->id,0,time_out);
	else
		Tau.SuspendThread(wt->id,1);	// else just suspend it
	SWITCH_CONTEXT;			// switch context
	if( wt->id == Tau.CurrentThreadID() ){   // now, switch back
		// but, my id is still in waitting list
		MaskDispatcher;
		do{
			sigItem *myItem = (sigItem*)waitL.focus();
			if (myItem->id == wt->id)	break;
		}while(waitL >> 1 );
		waitL.erase();	// remove item
		waitL.toHead();
		wt->id = 0;		// free item
		return ERR_SIGTIMEOUT;	// return time out
	}
	return ERR_NOERROR;
}

int far SIG :: post()
{
	MaskDispatcher;
	int rc=ERR_NOERROR;
	waitL.toHead();
	if( !waitL.is_empty()){
		do{
			sigItem far *wt = (sigItem far*)waitL.erase(); // remove the 1st one
			unsigned id = wt->id;	wt->id = 0;
			rc = Tau.ResumeThread(id,1);	// resume it
		}while( rc != ERR_NOERROR && !waitL.is_empty());
	}
	else	rc = ERR_SIGEMPTY;

	return rc;
}

int far SEM :: pend(unsigned time_out)
{int rc=ERR_NOERROR;
	MaskDispatcher;
	--S; // decrease counting
	if( S < 0 )
		if( (rc=SIG :: pend(time_out)) != ERR_NOERROR ){
			++S;
			ReleaseDispatcher;
			return rc;
		}
	ReleaseDispatcher;
	return rc;
}

int far SEM :: post()
{
	MaskDispatcher;
	++S;	// increase counting
	if( S<=0 ){
		SIG :: post();
		SWITCH_CONTEXT;
	}
	ReleaseDispatcher;
	return ERR_NOERROR;
}

int far EVENT :: pend(unsigned time_out)
{int rc=ERR_NOERROR;
	if( !trig ){
		MaskDispatcher;
		if( (rc=SIG :: pend(time_out)) != ERR_NOERROR ){
			ReleaseDispatcher;
			return rc;
		}
		ReleaseDispatcher;
	}
	trig = 0;
	return rc;
}

int far EVENT :: post()
{int count = 0;
	MaskDispatcher;
	trig = 1;
	while( SIG :: post() == ERR_NOERROR	)
		count ++;
	if( count )	{SWITCH_CONTEXT;}
	else			ReleaseDispatcher;
	return count;
}