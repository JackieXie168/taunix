一、前言
    此ReadME.TXT檔中包含了書附磁片的內容、已知的bug(s)、安裝方法以及未曾在
    書中提及的新功能。如有任何問題，歡迎隨時來信指教。作者之E-mail address
    為 jshu@ce01.cn.nctu.edu.tw 。
					作者謹識於國立交通大學控制工程係
							1995, 7, 31

二、磁片內容

    TAUOS.EXE       Tau-OS原始碼的自解壓縮檔
    TAUOS.LIB       Tau-OS的函式庫
    SVGABG55.EXE    數種SuperVGA的BGI螢幕卡驅動程式
    README.TXT      您正在看的檔案
	
	TAUOS.EXE解開後（見安裝方法），目錄與檔案有：

磁碟機 U 中的容體標號是 TVFS。
容體序列號碼是 631C:1EFA

目錄是 U:\work\tau

 5-22-95  13:47      <DIR>           0  .
 5-22-95  13:47      <DIR>           0  ..
 5-22-95  13:48      <DIR>           0  demo
 6-06-95  10:25      <DIR>           0  exe
 5-30-95  13:25      <DIR>           0  include
 6-06-95  10:06      <DIR>           0  PATCH
 5-22-95  13:48      <DIR>           0  src
        7 個檔案          0 位元組

目錄是 U:\work\tau\demo

 5-22-95  13:48      <DIR>           0  .
 5-22-95  13:48      <DIR>           0  ..
 6-06-95  10:30       1418           0  demo1.cpp
 4-15-95  10:55       1048           0  DEMO3.CPP
 5-30-95  13:24       1310           0  DEMO4.CPP
 5-07-95  15:32       1690           0  FACE.CPP
 6-05-95  11:04       3503           0  MSIM.CPP
 5-27-95  16:25       2072           0  PH.CPP
 5-05-95  12:08       3719           0  RSBENCH.CPP
        9 個檔案      14760 位元組

目錄是 U:\work\tau\exe

 6-06-95  10:25      <DIR>           0  .
 6-06-95  10:25      <DIR>           0  ..
 4-12-95  14:30      31544           0  DEMO1.EXE
 4-15-95  10:51      51292           0  DEMO3.EXE
 6-06-95  10:23      53214           0  DEMO4.EXE
 2-18-92   3:00       5554           0  EGAVGA.BGI
 4-21-95  11:03      43639           0  FACE.EXE
 6-05-95  11:04      66828           0  MSIM.EXE
 3-21-95  12:56      45349           0  PH.EXE
 5-05-95  12:08      66887           0  RSBENCHV.EXE
 8-23-94   0:58       8910           0  SVGA16.BGI
       11 個檔案     373217 位元組

目錄是 U:\work\tau\include

 5-30-95  13:25      <DIR>           0  .
 5-30-95  13:25      <DIR>           0  ..
 6-13-95  17:09       1214           0  COMM.H
 4-21-95  16:58       4344           0  KERNEL.H
 3-14-95  18:58       1917           0  LIST.H
 5-30-95  13:06        900           0  SEMEVENT.H
 3-10-95  23:33        797           0  TASKMGR.H
 3-08-95  15:35        343           0  TAUERR.H
 2-27-95  21:58        709           0  TAUOBJ.H
 4-25-95  23:32       1581           0  TAUOS.H
 5-30-95  13:26       1736           0  TPIPE.h
       11 個檔案      13541 位元組

目錄是 U:\work\tau\PATCH

 6-06-95  10:06      <DIR>           0  .
 6-06-95  10:06      <DIR>           0  ..
 6-06-95  10:22       2821           0  COMM.CPP
 6-06-95  10:08       1198           0  COMM.H
 7-26-95  12:56       1464           0  IDGEN.CPP
 7-26-95  10:51        755           0  IDGEN.H
 7-26-95  17:26      13540           0  KERNEL.CPP
 7-26-95  13:12       4911           0  KERNEL.H
 7-26-95  12:38       3344           0  TASKMGR.CPP
 7-26-95  12:19       1026           0  TASKMGR.H
 7-26-95   9:57        359           0  TAUERR.H
 7-26-95  12:18        442           0  TAUSTART.CPP
       12 個檔案      29860 位元組

目錄是 U:\work\tau\src

 5-22-95  13:48      <DIR>           0  .
 5-22-95  13:48      <DIR>           0  ..
 5-30-95  13:02       2640           0  COMM.CPP
 3-05-95  20:34       1206           0  FTEST.CPP
 4-21-95  10:51       3834           0  INTHDL.CPP
 6-06-95  10:15      13466           0  KERNEL.CPP
 4-12-95  15:06       3219           0  LIST.CPP
 5-30-95  12:45       2764           0  SEMEVENT.CPP
 4-12-95  15:10       2470           0  TASKMGR.CPP
 4-21-95  11:02        449           0  TAUSTART.CPP
 7-26-95  12:59       1021           0  WELCOME.CPP
       11 個檔案      32089 位元組

列示全部檔案:
       62 個檔案     463467 位元組
                    1073741824 個位元組可用

    其中src目錄下的檔案為課本中所解釋的程式，而patch目錄下的檔案是一些bugs
    的修正與功能加強﹝見下文“四、新增功能”說明﹞。TAUOS.LIB中所含的是修
    正後的版本。此外，在DEMO目錄中並沒有DEMO2.CPP，因為DEMO1與DEMO2除了程
    式的寫法略有不同外，其執行效果是完全一樣的，因此建議讀者試著將DEMO1改成
    DEMO2，作為對工作管理程式的一個練習。相關參考資料請查看附錄C核心服務
    與附錄D程式設計手冊。
	
三、安裝方法
    [1]首先須建一目錄存放所有檔案。
	example : 安裝在C碟的根目錄下

		C:\>MD TAU

    [2]從書附的磁片中，解開TAUOS.EXE。
	example : 

		C:\>CD TAU
		C:\TAU>A:\TAUOS -d *.*

    [3]將TAUOS.LIB拷進的Turbo C++3.0的LIB目錄中、INCLUDE目錄中所有的.H檔拷進
    Turbo C++3.0的INCLUDE目錄（包括PATCH下的*.H檔）後，安裝即告完成。

    使用時記得必須用PROJECT檔將TAUOS.LIB連結進來，且以Huge的memory model進行
    編譯。

四、新增功能
    [1] void TauGiveUpSlice()
    使用於Time slicing的工作中，目的在於使工作自願釋放CPU使用權，以增加CPU
    使用的效率。詳細使用方法請參考Tau-OS之程式設計參考手冊與核心服務參考手
    冊。

    [2] unsigned TauKernel :: HowManyThread()
    用於查詢核心中目前所有等候執行的執行段，包括THREAD_CURRENT、THREAD_READY
    、THREAD_SUSPEND、THREAD_WAIT、THREAD_DELAY等。

    [3] unsigned TauKernel :: HowManyFreeID()
    用於查詢係統中還剩多少可用的ID。磁片中的Tau-OS在ID的決定上有所修正，詳
    見「已知的bug(s)」的第五項。
    新的係統將限制THREAD_EVENTDRIVEN與THREAD_TIMESLICING兩種執行段的數量總
    合不能超過1024個，THREAD_TIMECRITICAL則維持原設計。
                                                 
五、已知的bug(s)
    Tau-OS version0.7目前仍屬alpha測試階段，由於在DOS下事實上並沒有好的多工
    除錯器，而使得Tau-OS的除錯相當麻煩。下面列出的是作者運用Tau-OS在一些即時
    模擬與DSP實驗時所發現的幾個問題與解決方法。

    [1]TPIPE的初始化：
        TPIPE在使用時，原則上是宣告成全域性的物件。當TPIPE以靜態方式宣告時
        ，在測試過程中並沒有發生問題，但若須要採動態宣告或使用陣列型態，則
        必須注意的是：如果整個專案計劃（project）使用不只一個.CPP檔，而且
        TPIPE的指標是在兩個檔案模組間傳遞資料的話，則TPIPE必須在接收端的模
        組中進行初始化的工作，見下列範例程式：

            在接收端模組：
                #include "tauos.h"
                TPIPE<int>  *iPipe;
                TASK Receiver(ARG)
                {
                    MaskDispatcher; //使核心進入臨界區
                    iPipe = new TPIPE<int>(20); //20個整數
                    ReleaseDispatcher;
                    int data;
                    *iPipe >> data;
                    ...
                }
            在傳送端模組：
                #include "tauos.h"
                extern TPIPE<int>   *iPipe;
                TASK Sender(ARG)
                {
                    while(iPipe==NULL); //等候iPipe指標被初始化
                    *iPipe << 55;
                    ...
                }

        在動態使用TPIPE（陣列亦然）時，若不依上述方法，程式便會當掉。因此
        若非得已請儘量以靜態方式使用TPIPE，動態或陣列則請使用上述建議的寫
        法，以避免時間上的浪費。

	[2]TauGiveUpSlice()
        若程式中數個工作均呼叫此功能，有時亦會導致當機。發生的原因不明，但
        可調整tick rate來避掉此問題。

	[3]訊息傳遞係統
        在PORT物件中，內含有一個EVENT物件，使工作在沒有訊息封包時可以進入
        等候狀態。但若在其他訊息傳遞係統，如TPIPE，也同樣作出相同的功能的
        話（見以下程式），在合併使用PORT與TPIPE時會產生當機。

		class far QMSG : public TPIPE<unsigned>{
		 private:
			EVENT	msg;
		 public:
			int operator<<(unsigned m);
			int operator>>(unsigned& m);
		};

        目前測試的結果只知道是因為EVENT物件的存在，確實的原因仍不清楚。因此
        解決此問題的方法即是不在此狀況下使用EVENT物件，而直接使用核心服務：
        Tau.SuspendThread()與Tau.ResumeThread()進行工作的等待與回復。

		class far QMSG : public TPIPE<unsigned>{
		 private:
			unsigned inWait:1;	// 指示工作是否進入等待
			unsigned ID;
		 public:
			int operator<<(unsigned m);
			int operator>>(unsigned& m);
		};
		
		int operator<<(unsigned m)
		{int rc;
			rc = TPIPE<unsigned>::operator<<(m);
			if( rc == ERR_NOERROR && inWait){
				Tau.ResumeThread(ID,1); // 回復等待狀態
				SWITCH_CONTEXT;	//注意：inline function不能使用inline assembly
			}
			return rc;
		}
		int operator>>(unsigned& m)
		{int rc;

			if((rc = (*msg)>>m)!=ERR_NOERROR){
				inWait = 1;
				Tau.SuspendThread(PTID,1);
				ID = PTID;
				SWITCH_CONTEXT;
				rc = (*msg)>>m;
				inWait = 0;
			}
			return rc;
		}

        磁片上函式庫的PORT物件也已不使用EVENT，新的程式碼放在PATCH目錄中。

    [4]在沒有數學輔助運算器的電腦上，係統亦可能當機。
        Tau-OS在測試87時使用的均為non-wait指令，在測得無x87存在時也不會對87
        動作，原則上是不會發生問題的。但在無x87的係統上，一般都會使用Turbo
        C++的87模擬函式庫，但此函式庫應是不可重複進入的，因此若多個工作同時
        使用到數學運算，就會發生當機。要解決這問題，只能用旗號（Semaphore）
        限制同時使用數學運算的工作數，或進入臨界區，不過這會嚴重影響執行效
        率，所以建議您買顆87比較好。

    [5]核心中ID的決定
        在原設計中，執行段或工作ID是將一16位元的整數分成三個欄位：
            bit15-14 ： 執行段種類
            bit13-10 ： 執行段的優先權
            bit9-0   ： 執行段產生的順序
        前兩欄並無問題，第三欄所謂產生順序也就是指此新的執行段是目前係統中
        第幾個執行段，亦即TauKernel中的ThreadCount屬性。
        ThreadCount在TauKernel::CreateThread中會被加一，在TauKernel::
        KillThread中被減一，當TauKernel::KillThread kill的不是先前最後一個
        產生出來的執行段的話，下一次產生執行段時，將產生ID重複的bug。因此必
        須重寫ID決定的方式。

        新係統中ID的產生將倚靠一個IDGenerator物件（見PATCH\IDGen.H）。
        IDGenerator中用一個含有1024個位元的陣列記錄1024個ID的使用情況。當
        須要產生新ID時，IDGenerator會以線性搜尋加first fit的方法在ID陣列中
        找尋未使用的ID。

        IDGenerator有三個成員函式：
        int GenerateID(unsigned& id)
            找出一個未在使用中的ID。
            參數：  id：新ID的輸出。
            傳回值：    成功：ERR_NOERROR
                        失敗：ERR_NOFREEID
        void ReleaseID(unsigned id)
            釋放使用中的ID。
            參數：  id：欲釋放的ID。在Tau-OS中，此值應不會超過0至1023，因
                為Tau-OS的ID僅有10bits是由IDGenerator所決定，另外若釋放一個
                未使用的ID，則IDGenerator將此情況視為don't care。

        unsigned CountFreeID()
            傳回目前所有可用ID的數量。

        詳細的設計請查看PATCH\IDGen.H、PATCH\IDGen.CPP。
        其他因ID設計改變而必須更動的有：
            TauKernel :: CreateThread
            TauKernel :: KillThread
            TaskMGR :: CreateTimeTask
            TaskMGR :: CreateEventTask
            TaskMGR :: CreateSliceTask
        在TaskMGR方面，除應IDGenerator所做的修正外，尚改正當無法產生新Task
        時卻未釋放已配置的記憶體的bug。在程式界面上，除產生Task時（Event-
        driven與Time-slicing task）會多傳回ERR_NOFREEID的錯誤碼表示核心中已
        無可用的ID外，其餘完全沒有更動。
        此外尚有原本在Kernel.CPP中的CleanerThread已移到TaskMGR模組中，並更
        名為CleanerTask，以期隔開核心與記憶體管理的關係，同時使Task的產生與
        消滅能使用同一組的記憶體管理程式（farmalloc/farfree）。詳細設計請查
        看PATCH目錄下的Kernel.H、Kernel.CPP、TaskMGR.H、TaskMGR.CPP、
        TauStart.CPP。

        磁片上的TauOS.LIB是完全修正過版本，可直接使用，同時版本號碼也推進到
        Tau-OS version 0.75。
----------------------------------That's all-----------------------------------
