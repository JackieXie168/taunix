//***************************************************************
//	Face.cpp						*
//	A demo program for testing Tau-OS kernel (semaphore).	*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <bios.h>
#include "tauos.h"
char *string[]={"This is a demo of Tau-OS.                       ",
			 "Press Enter to create another face (Max is 20). ",
			 "Press Esc to exit program.                      ",
			 "Thank you for playing me!!                      "
					 };

void far face(void far *arg)
{
 int y = * (int*) arg;
 int prex = 1,x = 1,step=1;
 int wait;
	MaskDispatcher;
	wait = random(20)+1;
	ReleaseDispatcher;
	while(1){
		VIDEO_Begin
			gotoxy(prex,y);
			putch(' ');
			gotoxy(x,y);
			putch(1);
		VIDEO_End
		if(x == 80 )	step = -1;
		if(x == 1  )	step = 1;
		prex = x;
		x = x + step;
		TauTimeDelay(wait);
	}
}

void far print(void far *)
{int i=0;
	while(1){
		i = i%4;
		VIDEO_Begin
			gotoxy(5,25);
			printf("%s",string[i]);
		VIDEO_End
		i++;
		TauTimeWait();
	}
}


EVENT	kb_press;
void far kb(void far *)
{int count=0;
 unsigned id;
 union {
	char byte[2];
	int  word;
 } key;

	while(1){
		kb_press.pend();
		key.word = bioskey(0);
		switch(key.byte[1]){
		 case 28:
			if( count == 20 )	break;
			count++;
			TauCreateSliceTask(id,face,(ARG)&count,1024,15);

			break;
		 case 1:
			TauShutDown;
			break;
		}
	}
}

TASK kb_trig(void far*)
{
	while(1){
		if( bioskey(1) )
			kb_press.post();
		else
			TauGiveUpSlice();
	}
}

void far TauMain(int ,char *[])
{unsigned id;
	clrscr();
	randomize();
	TauCreateTimeTask(id,print,0L,4096,14,80);
	TauCreateEventTask(id,kb,0L,4096,15);
	TauCreateSliceTask(id,kb_trig,0L,4096,15);
	_setcursortype(_NOCURSOR);
	TauStart(20);
	_setcursortype(_NORMALCURSOR);
}