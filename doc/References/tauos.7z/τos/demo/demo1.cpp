//***************************************************************
//	Demo1.cpp						*
//	A demo program for testing Tau-OS kernel.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "kernel.h"
#define	Tick_Rate	20

#include <conio.h>
#include <malloc.h>

TauKernel Tau;	// Initialize kernel class


double sec=0;	// Global variable used for communication

void far second(void far *arg)
{
	while(1){	// Calculate sec from TauKernel's timer tick
		sec = Tau.GetTime() / 20.0;
	}
}

void far print(void far *arg)
{
	while(sec <= 20.0 ){	// Print sec on the screen
		gotoxy(1,12);
		cprintf("Execution Time : %lf seconds",sec);
	}
	Tau.ShutDown = 1;
	while(1);	// Since not setting thread's return address,
			// we let it in an infinite loop.
			// When next timer interrupt comes, CS:IP will
			// jump to main()
}

void main()
{
 /* Allocate threads' stacks */
 void far *st_sec = farmalloc(4096);
 void far *st_print = farmalloc(4096);

 /* Prepare two thread objects */
 Thread *th_sec = new Thread;
 Thread *th_print = new Thread;

 /* Setup thread object with no argument, priority level 14, and
    time-slicing type of threads */
	th_sec->setup(second,NULL,st_sec,4096,14,THREAD_TIMESLICING,0,NULL);
	th_print->setup(print,NULL,st_print,4096,14,THREAD_TIMESLICING,0,NULL);

	/* Hand in two thread objects to kernel */
	Tau.CreateThread(th_sec);
	Tau.CreateThread(th_print);

	clrscr();

	/* Start kernel with Tick_Rate */
	Tau.Start(Tick_Rate);

	/* After print()'s Tau.ShutDown = 1 statement,
	   CS:IP will be back here */
}
