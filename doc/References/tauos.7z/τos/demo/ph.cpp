//***************************************************************
//	Ph.cpp							*
//	A demo program for semaphore handling.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "tauos.h"
#include <conio.h>
#include <stdlib.h>
#include <bios.h>
SEM stick[5];
int ph_sticks[5][2]={{0,1},{1,2},{2,3},{3,4},{4,0}};

TASK philosopher(ARG arg)
{
 int no = *(int*)arg;
	VIDEO_Begin
		gotoxy(1+16*no,10);
		cprintf("Philosopher%d",no);
		gotoxy(1+16*no,11);
		cprintf("I'm thinking");
	VIDEO_End
	int time;
	while(1){
		MaskDispatcher;
		time = random(100);
		ReleaseDispatcher;
		TTimeDelay(time+1);

		VIDEO_Begin
			gotoxy(1+16*no,11);
			cprintf("I'm hungry  ");
		VIDEO_End

		int dead = 0;
		if(stick[ph_sticks[no][0]].wait(120)!=ERR_NOERROR)	dead = 1;
		else{
			VIDEO_Begin
				gotoxy(1+16*no,12);
				cprintf("I hold stick%d",ph_sticks[no][0]);
			VIDEO_End
		}
		if(!dead){
			if(stick[ph_sticks[no][1]].wait(120)!=ERR_NOERROR){
				dead = 1;
				stick[ph_sticks[no][0]].signal();
				VIDEO_Begin
					gotoxy(1+16*no,12);
					cprintf("             ");
				VIDEO_End
			}
			else{
				VIDEO_Begin
					gotoxy(1+16*no,13);
					cprintf("I hold stick%d",ph_sticks[no][1]);
				VIDEO_End
			}
		}
		if(dead){
			VIDEO_Begin
				gotoxy(1+16*no,11);
				cprintf("I'm dead    ");
			VIDEO_End
			return;
		}
		VIDEO_Begin
			gotoxy(1+16*no,11);
			cprintf("I'm eatting ");
		VIDEO_End

		MaskDispatcher;
		time = random(100);
		ReleaseDispatcher;
		TTimeDelay(time+1);

		VIDEO_Begin
			gotoxy(1+16*no,12);
			cprintf("              ");
			gotoxy(1+16*no,13);
			cprintf("              ");
		VIDEO_End

		stick[ph_sticks[no][0]].signal();
		stick[ph_sticks[no][1]].signal();

		VIDEO_Begin
			gotoxy(1+16*no,11);
			cprintf("I'm thinking");
		VIDEO_End
	}
}

TASK end(ARG arg)
{
	while(!bioskey(1));
	bioskey(0);
	TShutDown;
}


void far TauMain(int argc,char **argv)
{
 int arg[5];
 unsigned id;
	randomize();

	gotoxy(1,5);
	cprintf("This is a demo of 5 philosophers' problem");
	for(int i=0 ; i<5 ; i++){
		arg[i] = i;
		TCreateSliceTask(id,philosopher,(ARG)&arg[i],1024,15);
	}
	TCreateSliceTask(id,end,0L,1024,15);

	TStart(20);
}