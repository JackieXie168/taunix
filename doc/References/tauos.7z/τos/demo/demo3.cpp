//***************************************************************
//	Demo3.cpp						*
//	A demo program for testing Tau-OS kernel.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "tauos.h"
#define	Tick_Rate	20

#include <conio.h>

TPIPE <double> 	sec;
void far second(void far *arg)
{
	while(1){	// Calculate sec from TauKernel's timer tick
		sec << Tau.GetTime() / 20.0;
	}
}

void far print(void far *arg)
{double sec=0.0;
	while(sec <= 20.0/* sec means local variable double sec*/ ){
	// Print sec on the screen
		:: sec >> sec;	// ::sec means global variable TPIPE<double> sec
		gotoxy(1,12);
		cprintf("Execution Time : %lf seconds",sec);
	}
	Tau.ShutDown = 1;	// shut down system
}
/*
	Here use TauMain instead of main to be the entry point of user program.
	main() is in TAUSTART.CPP and used to initialize all Tau-OS' objects.
*/

void TauMain(int argc,char **argv) // argc & argv will be passed by main()
{
 unsigned id;

	Task.CreateSliceTask(id,second,NULL,4096,15);
	Task.CreateSliceTask(id,print,NULL,4096,15);

	clrscr();

	/* Start kernel with Tick_Rate */
	Tau.Start(Tick_Rate);

	/* After print()'s Tau.ShutDown = 1 statement,
	   CS:IP will be back here */
}