//***************************************************************
//	Msim.cpp						*
//	A demo program for real-time motor control simulation.	*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <graphics.h>
#include <stdio.h>
#include <conio.h>
#include <bios.h>
#include <stdlib.h>
#include "tauos.h"

double x_ratio,y_ratio;
double x[2],x1[2],y,u,e,e1,R=0,P=0,I=0;

double A[4]={0.9509,-0.0585,0.0098,0.9997},
	  B[2]={0.0098,0.0},
	  C[2]={0.0,3.0};

TASK	msim()
{
	x[0]=x1[0];x[1]=x1[1];	// old X
	e1 = e;				// old error
	e = R-y;				// new error

	u = u+P*(e-e1)+I*e1;	// controller

	x1[0]=A[0]*x[0]+A[1]*x[1]+B[0]*u;
	x1[1]=A[2]*x[0]+A[3]*x[1];
	y = C[1]*x[1];
}

TASK show_motor(ARG arg)
{int x=0,y=200;
 unsigned long count=0;
 char output[20];
	while(1){
		VIDEO_Begin
			setviewport(20*x_ratio,20*y_ratio,620*x_ratio,420*y_ratio,1);
			moveto(x*x_ratio,y*y_ratio);

			x = (TauGetTime()-count*1500)*0.4;
			y = 200 - ( ::y * 100 );
			if(x>=600){
				clearviewport();
				setcolor(RED);
				line(0,200*y_ratio,600*x_ratio,200*y_ratio);
				setlinestyle(DOTTED_LINE,1,NORM_WIDTH);
				line(0,100*y_ratio,600*x_ratio,100*y_ratio);
				line(0,300*y_ratio,600*x_ratio,300*y_ratio);
				setlinestyle(SOLID_LINE,1,NORM_WIDTH);
				setcolor(YELLOW);
				x=0;
				count++;
				moveto(x*x_ratio,y*y_ratio);
			}
			else	lineto(x*x_ratio,y*y_ratio);
			sprintf(output,"%lf",::y);
			setviewport(90*x_ratio,440*y_ratio,200*x_ratio,450*y_ratio,0);
			clearviewport();
			outtextxy(0,0,output);
		VIDEO_End
		TauGiveUpSlice();
	}
}

TASK keyboard(ARG arg)
{char ps[50],is[50],rs[50];
 double p=0.0,i=0.0,r=0.0;
	while(1){
		while(!bioskey(1));
		unsigned key = bioskey(0);
		switch(key&0x00ff){
		 case '9':	p+=0.01;	break;
		 case '6':	p-=0.01;	break;
		 case '8':	i+=0.01;	break;
		 case '5':	i-=0.01;	break;
		 case '7':	r+=0.01;	break;
		 case '4':	r-=0.01;	break;
		 case 13:		P=p;	I=i;	R=r;	break;
		 case 27 :	TauShutDown;	return;
		 default:	continue;
		}
		VIDEO_Begin
			sprintf(ps,"%lf",p);
			sprintf(is,"%lf",i);
			sprintf(rs,"%lf",r);
			setviewport(115*x_ratio,455*y_ratio,300*x_ratio,465*y_ratio,0);
			clearviewport();
			outtextxy(0,0,rs);
			setviewport(525*x_ratio,440*y_ratio,600*x_ratio,450*y_ratio,0);
			clearviewport();
			outtextxy(0,0,ps);
			setviewport(525*x_ratio,460*y_ratio,600*x_ratio,470*y_ratio,0);
			clearviewport();
			outtextxy(0,0,is);
		VIDEO_End
	}
}

TASK noise(ARG arg)
{
	randomize();
	while(1){
		x1[1] += ((double)random(1000)-500)/400000.0;
		TauGiveUpSlice();
	}
}

void far TauMain(int argc,char **argv)
{
 int gdriver=DETECT,gmode;
 unsigned id;
	TauCreateSliceTask(id,show_motor,NULL,4096);
	TauCreateSliceTask(id,keyboard,NULL,4096,14);
	TauCreateSliceTask(id,noise,NULL,4096,14);
	TauSetTickISR(msim);
	initgraph(&gdriver,&gmode,"");
	x_ratio = getmaxx() / 640.0;
	y_ratio = getmaxy() / 480.0;
	rectangle(19*x_ratio,19*y_ratio,621*x_ratio,421*y_ratio);
	setcolor(RED);
	line(20*x_ratio,220*y_ratio,620*x_ratio,220*y_ratio);
	setlinestyle(DOTTED_LINE,1,NORM_WIDTH);
	line(20*x_ratio,120*y_ratio,620*x_ratio,120*y_ratio);
	line(20*x_ratio,320*y_ratio,620*x_ratio,320*y_ratio);
	setlinestyle(SOLID_LINE,1,NORM_WIDTH);
	setcolor(WHITE);
	outtextxy(50*x_ratio,5*y_ratio,"Dynamic Simulation : G(s) = 3/(s^2+5s+6) Sampling period : 0.01 sec");
	outtextxy(20*x_ratio,440*y_ratio,"Output : ");
	outtextxy(20*x_ratio,455*y_ratio,"Reference : ");
	outtextxy(410*x_ratio,440*y_ratio,"P controller : ");
	outtextxy(410*x_ratio,460*y_ratio,"I controller : ");
	setcolor(YELLOW);

	TauStart(100);

	closegraph();
}
