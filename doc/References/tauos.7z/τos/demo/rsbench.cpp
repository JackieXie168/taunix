//***************************************************************
//	Rsbench.cpp						*
//	A benchmark testing program by using Tau-OS.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <dos.h>
#include <bios.h>
#include <math.h>
#include <graphics.h>

#include <svgautil.h>
#include <svgas3.h>
#include <svga16.h>

#include <conio.h>
#include <stdio.h>
#include "tauos.h"

#define TASKNO	12
typedef struct{
	int x,y;
	int sampling_period;
} Arg;

typedef struct{
	unsigned long time;
	double output;
}DATA;

class far WAVE : public TPIPE<DATA>{
 public:
	WAVE(int size=250):TPIPE<DATA>(size){;}
};

WAVE output[TASKNO];

Arg init_data[]={
	{10,20,1},{210,20,2},{410,20,3},{610,20,4},
	{10,120,5},{210,120,6},{410,120,7},{610,120,8},
	{10,220,9},{210,220,10},{410,220,11},{610,220,12}};
int no[] = {0,1,2,3,4,5,6,7,8,9,10,11};

double x_ratio,y_ratio;
unsigned long full_add;
unsigned long A;
unsigned task_no;

void far signal()
{DATA d;
 int period;
	d.output = sin(0.02*M_PI*TauGetTime());
	d.time = TauGetTime();
	for(int i=0 ; i<task_no ; i++){
		period = init_data[i].sampling_period;
		if( (TauGetTime() % period)==0 )
			output[i] << d;
	}
}

TASK sampling(ARG arg)
{
 int index = *(int*)arg;
 Arg	*init = &init_data[index];
 char s[50];
 int vx=0,vy=40;
	VIDEO_Begin
		setcolor(WHITE);
		sprintf(s,"Period : %d tick(s)",init->sampling_period);
		setviewport(0,0,getmaxx(),getmaxy(),1);
		outtextxy((init->x)*x_ratio,(init->y-10)*y_ratio,s);
		setviewport(init->x*x_ratio,init->y*y_ratio,
			(init->x+180)*x_ratio,(init->y+80)*y_ratio,1);
		rectangle(0,0,180*x_ratio,80*y_ratio);
		moveto(0,40*y_ratio);
	VIDEO_End
	unsigned long old_vx;
	DATA sample;

	while(1){
		while((output[index]>>sample)!=ERR_NOERROR)
			TauGiveUpSlice();
		VIDEO_Begin
			setviewport(init->x*x_ratio,init->y*y_ratio,
				(init->x+180)*x_ratio,(init->y+80)*y_ratio,1);
			moveto(vx*x_ratio,vy*y_ratio);

			old_vx = vx;
			vx = (sample.time%500)*0.36;
			vy = 40 - sample.output*35;
			if( vx < old_vx ){
				clearviewport();
				setcolor(WHITE);
				rectangle(0,0,180*x_ratio,80*y_ratio);
				moveto(vx*x_ratio,40*y_ratio);
			}
			else{
				setcolor(YELLOW);
				lineto(vx*x_ratio,vy*y_ratio);
			}
		VIDEO_End
	}
}

TASK kb(ARG arg);
TASK ShowAdd(ARG arg)
{char s[200];
 unsigned id;
	TauTimeWait();
	full_add = A;
	A=0;
	clearviewport();
	sprintf(s,"Full Addtion : %lu in 5 sec",full_add);
	outtextxy(300*x_ratio,520*y_ratio,s);
	outtextxy(50*x_ratio,450*y_ratio,"Press Enter to Create Task...");
	TauCreateSliceTask(id,kb,NULL,1024,14);
	asm cli;
	TauSetTickISR(signal);
	asm sti;

	while(1){
		VIDEO_Begin
			sprintf(s,"Addition : %lu per 5 sec, %lu %% ",
								A,A/(full_add/100));
			setviewport(300*x_ratio,550*y_ratio,
							799*x_ratio,599*y_ratio,0);
			clearviewport();
			setcolor(WHITE);
			outtextxy(0,0,s);
		VIDEO_End
		A = 0;
		TauTimeWait();
	}
}

TASK add(ARG arg)
{unsigned long step = 1;
	while(1)	A+=step;
}



TASK kb(ARG arg)
{unsigned key,id;

	while(1){
		while(!bioskey(1))	TauGiveUpSlice();
		key = bioskey(0);
		if((key&0x00ff)==13){
			if(task_no<12){
				TauCreateSliceTask(id,sampling,&no[task_no],4096);
				task_no++;
			}
		}
		else	TauShutDown;
	}
}

int huge DetectVGAS3()
{	return SVGAS3_1024x768x256;	}
int huge DetectVGA16()
{	return SVGA1024x768x16;	}

void far TauMain(int argc,char **argv)
{
 int gdriver=DETECT,gmode;
 unsigned id;
	installuserdriver("Svga16",DetectVGA16);

	initgraph(&gdriver,&gmode,"");
	int errorcode = graphresult();
	if(errorcode != 0)	return;

	TauCreateTimeTask(id,ShowAdd,NULL,1024,15,500);
	TauCreateSliceTask(id,add,NULL,1024,15);


	x_ratio = getmaxx()/800.0;
	y_ratio = getmaxy()/600.0;
	outtextxy(1,1,"Wait for 5 sec...");
	TauStart(100);
	closegraph();
}
