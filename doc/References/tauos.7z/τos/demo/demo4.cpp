//***************************************************************
//	Demo4.cpp						*
//	A demo program for testing Tau-OS kernel.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <stdio.h>
#include <conio.h>

#include "tauos.h"
class StringMsg : public MSGPack{
 private:
	char *string;
 public:
	void String(char *s)	{	string = s;	}
	char *String()		{	return string;	}
};

TASK Doc(ARG arg)
{unsigned tid = *(unsigned *)arg;
 char *string[2]={
	"This is a demo of communication manager\n",
	"Message is passed from Task:%u to Task:%u\n"
	};
 StringMsg	*str;
	TauTimeDelay(25);
	for(int i=0 ; i<2 ; i++){
		MaskDispatcher;
		str = new StringMsg;
		ReleaseDispatcher;
		str->Receiver = tid;
		str->MSGID    = 1;
		str->String(string[i]);
		COMM << str;
	}
}

TASK ShowDoc(ARG)
{
 PORT	p;
 StringMsg	*str;
	str = (StringMsg*)p.GetMessage(100);
	if(str == NULL)	printf("Time out!!\n");
	else{
		printf(str->String());
		MaskDispatcher;
		delete str;
		ReleaseDispatcher;
	}
	str = (StringMsg*)p.GetMessage(100);
	if(str == NULL)	printf("Time out!!\n");
	else{
		printf(str->String(),str->Sender(),PTID);
		printf("Message ID is %u\n",str->MSGID);
		MaskDispatcher;
		delete str;
		ReleaseDispatcher;
	}
	TauShutDown;
}

void TauMain(int,char**)
{
 unsigned id1,id2;
	TauCreateSliceTask(id1,ShowDoc,NULL,4096);
	TauCreateSliceTask(id2,Doc,(ARG)&id1,4096);

	TauStart(50);
	printf("Press any key to quit...");
	getch();
}