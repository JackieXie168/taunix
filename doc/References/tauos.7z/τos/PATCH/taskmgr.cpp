//***************************************************************
//	Taskmgr.cpp						*
//	Definitions of task manager.				*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Revised version:					*
//		Changing the task ID generation method		*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include "kernel.h"
#include "taskmgr.h"
#include <malloc.h>

APIRET far TaskMGR :: AllocThread(Thread **th,void far **stack,unsigned stack_size)
{
	*th = (Thread*)farmalloc(sizeof(Thread));
	*stack = farmalloc(stack_size);
	if( *th == NULL || *th == NULL ){
		if( *th )		farfree(th);
		if( *stack )   farfree(stack);
		return	ERR_NOSPACE;
	}
	return ERR_NOERROR;
}

void far TaskMGR :: FreeThread(Thread *th)
{
	th->status = THREAD_FREE;
	Tau.DispatchMask = 1;
	farfree(th->Stack);
	farfree(th);
	Tau.DispatchMask = 0;
}

APIRET far TaskMGR :: CreateTimeTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio,unsigned period)
{
 Thread *thread=NULL;
 void far *stack=NULL;
	Tau.DispatchMask = 1;
	if(AllocThread(&thread,&stack,stack_size) == ERR_NOSPACE){
		Tau.DispatchMask = 0;
		return ERR_NOSPACE;
	}
	Tau.DispatchMask = 0;

	thread->setup(proc,arg,stack,stack_size,prio,
					THREAD_TIMECRITICAL,period,EndTask);

	APIRET rc;
	if((rc = Tau.CreateThread(thread)) != ERR_NOERROR)
		FreeThread(thread); // bad priority
	else	id = thread->tid;
	return rc;
}

APIRET far TaskMGR :: CreateEventTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio)
{
 Thread *thread=NULL;
 void far *stack=NULL;

	Tau.DispatchMask = 1;
	if( Tau.HowManyFreeID() == 0 ){
		Tau.DispatchMask = 0;
		return ERR_NOFREEID;
	}
	if(AllocThread(&thread,&stack,stack_size) == ERR_NOSPACE){
		Tau.DispatchMask = 0;
		return ERR_NOSPACE;
	}
	Tau.DispatchMask = 0;

	thread->setup(proc,arg,stack,stack_size,prio,
						THREAD_EVENTDRIVEN,0,EndTask);
	APIRET rc = Tau.CreateThread(thread);
	id = thread->tid;
	return rc;
}

APIRET far TaskMGR :: CreateSliceTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio)
{
 Thread *thread=NULL;
 void far *stack=NULL;
	Tau.DispatchMask = 1;
	if( Tau.HowManyFreeID() == 0 ){
		Tau.DispatchMask = 0;
		return ERR_NOFREEID;
	}
	if(AllocThread(&thread,&stack,stack_size) == ERR_NOSPACE){
		Tau.DispatchMask = 0;
		return ERR_NOSPACE;
	}
	Tau.DispatchMask = 0;

	thread->setup(proc,arg,stack,stack_size,prio,THREAD_TIMESLICING,0,EndTask);
	APIRET rc = Tau.CreateThread(thread);
	id = thread->tid;
	return rc;
}

APIRET far TaskMGR :: KillTask(unsigned id)
{
 Thread *thread;
	if( id == Tau.CurrentThreadID() )	return ERR_BADID;
	Tau.SuspendThread(id);
	APIRET rc = Tau.KillThread(id);
	Tau.DispatchMask = 0;
	return rc;
}

APIRET far TaskMGR :: SuspendTask(unsigned id)
{
 unsigned tid = Tau.CurrentThreadID();
	APIRET rc = Tau.SuspendThread(id);
	if( id == tid ){	SWITCH_CONTEXT;}
	return rc;
}

APIRET far TaskMGR :: ResumeTask(unsigned id)
{
	APIRET rc = Tau.ResumeThread(id);
	SWITCH_CONTEXT;
	return rc;
}

void far EndTask()
{
	Tau.SuspendThread(Tau.CurrentThreadID());
	Tau.KillThread(Tau.CurrentThreadID());
	SWITCH_CONTEXT;
}

void far CleanerTask(void far *)
// task to clean dead thread, must be set to time-slicing mode
{Thread *th;
	while(1){
		if( (th=Tau.ReturnDeadThread()) != NULL )
			Task.FreeThread(th);
		Tau.GiveUpSlice();
	}
}

