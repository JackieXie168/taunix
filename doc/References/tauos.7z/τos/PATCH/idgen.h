//***************************************************************
//	Idgen.h							*
//	The header file for task ID generator.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __IDGN_H__
#define __IDGEN_H__

#ifndef IDRANGE
#define IDRANGE	1024	// define how large an ID can be
#endif

/*
IDFlag is a structure to indicate if this id is in use or not.
*/
typedef struct {
	unsigned 	inUse:1;	// using flag
} IDFlag;


/*
IDGenerator will maintain an IDFlag array, find a free
ID, and release ID.
*/
class far IDGenerator{
 private:
	IDFlag	IDArray[IDRANGE];	// an IDFlag arraay
	unsigned	CurrentID;		// index indicator
	unsigned	noFreeID;			// number of free ID
 public:
	IDGenerator();
	int	GenerateID(unsigned& id);
	void	ReleaseID(unsigned id);
	unsigned CountFreeID();
};

inline unsigned IDGenerator :: CountFreeID()
{
	return noFreeID;		// return how many free id's are
}

#endif
