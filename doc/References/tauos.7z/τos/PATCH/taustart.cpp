//***************************************************************
//	Taustart.cpp						*
//	Definitions of the Tau-OS starting point.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Revised version:					*
//		Changing the task ID generation method.		*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <stdio.h>
#include <conio.h>
#include "tauos.h"

TauKernel 	far Tau;
TaskMGR 		far Task;
SEM			far video;
COMMGR	  	far COMM;

void far CleanerTask(void far *);
void far TauMain(int argc,char *argv[]);

void welcome();

void main(int argc,char *argv[])
{unsigned id;

	welcome();
	TauCreateSliceTask(id,CleanerTask,(void far *)NULL,1024);
	TauMain(argc,argv);
	gotoxy(1,25);
	printf("\nTau-OS Shuts Down!");
}
