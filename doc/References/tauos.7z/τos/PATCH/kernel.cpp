//***************************************************************
//	Kernel.cpp						*
//	Tau-OS kernel's definition.				*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Revised version:					*
//		Changing the task ID generation method		*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <stdio.h>
#include "kernel.h"

// Definition of IDGenerator
#include "u:\work\tau\patch\idgen.cpp"


// char *state[]={"Ready","Current","Suspend","Delay","Wait","Killing","Free"};

/* Globle variables declaration */

// Map and UnMap table used far scheduling
const char Map[]={ 0x01,0x02,0x04,0x08};
const char UnMap[]={ 0,0,1,0,2,0,1,0,3,0,1,0,2,0,1,0 };

unsigned char fpu_save[94];	//will store default fpu context

/* Function definitions*/
/* Object : Thread : setup => setup thread data */
void far Thread :: setup(void far (*_start_add)(void far*arg),
	   void far*arg,void far* _stack,unsigned stack_size,
		unsigned prio,int _type,unsigned rate,void far (*ret_add)(void))
{
	StartAdd = _start_add;	// thread's starting address
	Arg = arg;			// argument
	Stack = (unsigned char far*)_stack;	// thread stack
	SS = FP_SEG(Stack);
	StackSize = stack_size;
	unsigned far *Ustack;
	// setup stack
	/* stack frame:
		|                  |
		+------------------+
		|   94 bytes       |
		|reserved for 87's |
		|	context       |
		+------------------+
		|	CPU Context   |
		|	  18bytes     |
		+------------------+
		|IP of Start Addr  |
		+------------------+
		|CS of Start Addr  |
		+------------------+
		|CPU flag register |
		+------------------+
		|IP of Return Addr |
		+------------------+
		|CS of Return Addr |
		+------------------+
		|offset of arg     |
		+------------------+
		|DS of arg         |
		+------------------+
	*/
	// setting starting address
	Ustack = (unsigned *)&Stack[StackSize-14]; *Ustack = FP_OFF(StartAdd);
	Ustack = (unsigned *)&Stack[StackSize-12]; *Ustack = FP_SEG(StartAdd);
	// setting cpu flag
	Ustack = (unsigned *)&Stack[StackSize-10]; *Ustack = 0x0200;
	// setting return address
	Ustack = (unsigned *)&Stack[StackSize-8];  *Ustack =  FP_OFF(ret_add);
	Ustack = (unsigned *)&Stack[StackSize-6];  *Ustack =  FP_SEG(ret_add);
	// setting argument
	Ustack = (unsigned *)&Stack[StackSize-4];  *Ustack =  FP_OFF(Arg);
	Ustack = (unsigned *)&Stack[StackSize-2];  *Ustack =  FP_SEG(Arg);

	// the setting of SP&BP should depend on FPU(94bytes),
	// interrupt(18bytes), CPU's MSW, and thread argument(14bytes)
	SP = FP_OFF(&Stack[StackSize])-32-94;
	BP = SP+94;

	if( Tau.FPU_type() )	// if there has 87 on the system
		for( int i=0 ; i<94 ;i++)// store default context into stack
			Stack[StackSize-126+i] = fpu_save[i];

	_qItem :: priority(prio);	// setting priority

	type = _type;				// thread type

	//setup time-critical thread's sampling rate
	slice = slice_left = rate;
	status = THREAD_READY;
}

// ThreadQ's member function : Search thread in a thread queue
Thread* ThreadQ :: Get(unsigned id,int remove)
{
	if( no == 0 )	return NULL;	// no item
	Thread *ret=NULL;
	_queue :: toHead();
	do{	// search item
		if( Focus()->tid == id ){	// find one
			if( remove )			// if want to remove item
				ret = RemoveFocus();// remove it and return
			else	ret = Focus();		// else just return focus
			break;
		}
	}while( _queue :: operator >> (1));
	return ret;
}
/*
// ThreadQ's member function : destructor, used far debugging
ThreadQ :: ~ThreadQ()
{
	_queue :: toHead();
	Thread *t;
	printf("\nThread Queue : Count = %d",no);
	while(!_queue::is_empty()){
		t = (Thread *) _queue :: operator --();
		printf("\n Thread %u : priority : %u status : %s",
						t->tid,t->priority(),state[t->status-1]);
	}
}
*/

// TauKernel Object's member function definition
far TauKernel :: TauKernel() // constructor
{
	// initialize all flags
	TickCounter = 0;
	ShutDown = 0;
	DispatchMask = 0;
	ThreadCount = 0;

	FpuFlag = FPUTest();	// test FPU status
	if( FpuFlag ){	// store default fpu context
		_DX = _SS; _BX = _BP;
		_SS = FP_SEG(fpu_save);
		_BP = FP_OFF(fpu_save);
		asm fsave	[bp]
		_SS = _DX; _BP = _BX;

	}
		// setting ready queue and suspend queue
	ReadyQ[0] = & Event;	SuspendQ[0] = & EventSuspend;
	ReadyQ[1] = & Slice;  SuspendQ[1] = & SliceSuspend;
		// setting kernel-dependent ISR
	oldInt08h = getvect(0x08);
	oldIntFFh = getvect(0xff);
	oldIntFEh = getvect(0xfe);
	setvect(0xff,CTXTSW);           // used for context switching
	setvect(0xfe,oldInt08h);		  // PC's original int 08h
}

//Kernel API : Start
void far TauKernel :: Start(unsigned tick_rate)
{                          // tick_rate : set sample frequency
 union {
	char 		byte[2];
	unsigned	word;
 }rate;

	StartFlag = 1;	// set starting flag
	if( tick_rate ){
		rate.word = 1193180/tick_rate; // calculate 8253/4 timer count
		asm{
			mov al,0x34;	// 8253/4's command
			out 0x43,al;	// 8253/4's command register
		}
		_AL = rate.byte[0];	// low byte
		asm	out 0x40,al;
		_AL = rate.byte[1]; // high byte
		asm	out 0x40,al;
	}
	setvect(0x08,ClockISR);	// set clock isr
//	asm int 0xff;	    // call context switch directly, used for debugging
	while( StartFlag );	// wait StartFlag to be 0

	// return back to single task mode
	setvect(0x08,oldInt08h);	// reset all interrupt handler
	setvect(0xfe,oldIntFEh);
	setvect(0xff,oldIntFFh);
	if( tick_rate ){		// reset 8253/4 to 18.2 Hz
		rate.word = 65535;
		asm{
			mov al,0x34;
			out 0x43,al;
		}
		_AL = rate.byte[0];
		asm	out 0x40,al;
		_AL = rate.byte[1];
		asm	out 0x40,al;
	}
}

far TauKernel :: ~TauKernel() // destructor
{
	if( FpuFlag )	asm	finit;
	printf("\nThread Count : %u",ThreadCount);
}

// Kernel API : CreateThread
int far TauKernel :: CreateThread(Thread *th)
{
		// check thread type
		if( (th->type > 3) || (th->type < 1) )
			 return ERR_UNKNOWNTYPE;
		if(th->priority() > 15 )	th->priority(15);
		/* Code above is to correct error        */

		// decide thread id code
		DispatchMask = 1;
		unsigned id=0;
		if(th->type != THREAD_TIMECRITICAL &&
				IDGen.GenerateID(id) == ERR_NOFREEID){
			DispatchMask = 0;
			return ERR_NOFREEID;
		}
		ThreadCount++;

		th->tid = (th->type<<14) | (th->priority()<<10)+id;

		switch( th->type ){ // thread-type dispatch
		 case THREAD_TIMECRITICAL:
			if( Time[th->priority()] != NULL ){//if this priority exists
				DispatchMask = 0;
				return ERR_BADPRIORITY;	// return bad-priority error
			}
			Time[th->priority()] = th; // insert it and
			// setup the ReadyGroup & ReadyThread
			// This techneque is from Micro-C OS
			ReadyGroup |= Map[th->priority() >> 2];
			ReadyThread[th->priority()>>2] |= Map[th->priority() & 0x03];
					 break;
		 case THREAD_EVENTDRIVEN:
		 case THREAD_TIMESLICING:
			// decide thread id
			*ReadyQ[th->type-2] + th ;
			if( th->type == THREAD_TIMESLICING)
				// if thread type is THREAD_TIMESLICING,
				// set its slice.
				th->slice_left = th->slice = 16 - th->priority();
				break;
		}
		DispatchMask = 0;
		return        ERR_NOERROR;
}

// Kernel API : KillThread
//	ps : standard procedure of killing a thread is
//		1. suspend that therad
//		2. then remove it from suspend queue or
//				just remove it(for time-critical thread)!
int far TauKernel :: KillThread(unsigned id)
{
		// decode thread priority and type from tid
		unsigned type = id >> 14;
		unsigned priority = (id >> 10) & 0x000f;
		Thread *th;
		DispatchMask = 1;
		switch(type){
		 case THREAD_TIMECRITICAL:
			if( Time[ priority ] == NULL ){ // no this thread
				DispatchMask = 0;
				return ERR_BADID;
			}
			th = Time[priority];
			// remove it,thread should be suspended
			Time[priority] = NULL;
					 break;
		 case THREAD_EVENTDRIVEN:
		 case THREAD_TIMESLICING:
			// search for thread
			th = SuspendQ[type-2]->Get(id);
			if(th == NULL){
				DispatchMask = 0;
				return ERR_BADID;
			}
					 break;
		}
		th->status = THREAD_KILLING;
		if(th->tid == CurrentThreadID() )
			CurrentThread[type-1] = NULL;
		DeadQ + th;	// move th into dead queue
		ThreadCount --;
		IDGen.ReleaseID((th->tid&0x03FF));	// release used id
		return ERR_NOERROR;
}

// Kernel API : ReturnDeadThread
Thread * TauKernel :: ReturnDeadThread()
{Thread *th;
	if( DeadQ.is_empty()	)	return NULL;
	DispatchMask = 1;
	th = --DeadQ;
	DispatchMask = 0;
	return th;	// return dead thread back
}



// Kernel API : SuspendThread
//	ps : SuspendThread can suspend a thread,
//                          let it being waiting or just delay it.
int far TauKernel :: SuspendThread(unsigned id,int wait,int Delay)
{                                  // when wait != 0, means want to wait
							// when int Delay != 0, means delay
 unsigned priority,type;
 Thread *th = NULL;
	priority = (id>>10) & 0x000F;
	type	    = id>>14;

	// Serach for this thread
	DispatchMask = 1;
	switch(type){
	 case THREAD_TIMECRITICAL:
		th = Time[priority];
			break;
	 case THREAD_EVENTDRIVEN:
	 case THREAD_TIMESLICING:
		th = ReadyQ[type-2]->Get(id);
			break;
	}
	if( th == NULL ){	//	Still not found
		// then serach it in DelayQ
		if( !wait ) th = TimeDelay.Get(id);
		if( th == NULL){
			DispatchMask = 0;
			return ERR_BADID;	// no such thread
		}
	}
	// Now suspend it!
	// put it to suspend Q or delay Q
	switch(type){
	 case THREAD_TIMECRITICAL://Time-critical thread can't be delayed
		ReadyThread[priority>>2] &= ~Map[priority&0x03];
		if(!ReadyThread[priority>>2])	// no ready thread in this group
			ReadyGroup &= ~Map[priority>>2];
		if( wait )	th->status = THREAD_WAIT;	// set to THREAD_WAIT
		else			th->status = THREAD_SUSPEND;  // or THREAD_SUSPEND
			break;
	 case THREAD_EVENTDRIVEN:
	 case THREAD_TIMESLICING:
		if(Delay){// only event-driven or time-slicing thread can be delayed
			th->slice_left = Delay;	// Delay count
			TimeDelay + th;		// move to delay queue
			th->status = THREAD_DELAY;
		}
		else{
			*SuspendQ[type-2] + th;
			if( wait )	th->status = THREAD_WAIT;
			else			th->status = THREAD_SUSPEND;
		}
			break;
	}
	return ERR_NOERROR;
}

// Kernel API : ResumeThread
int far TauKernel :: ResumeThread(unsigned id,int wait)
{
 unsigned type = id>>14;
 unsigned priority = (id >> 10) & 0x000F;
 Thread	*thread = NULL;
	DispatchMask = 1;
	// Search for that thread
	// first, search it in time-critical table
	if( type == THREAD_TIMECRITICAL ){
		thread = Time[priority];
		if( (thread->status == THREAD_WAIT) && !wait )
			thread = NULL;
	}
	if(thread == NULL)
		// not found, search in delay queue
		thread = TimeDelay.Get(id);
	if( thread == NULL ){ // not found!search it in suspend queue again!!
		if( (thread = SuspendQ[type-2]->Get(id,0)) != NULL ){//no remove
			if( (thread->status == THREAD_WAIT) && !wait )
				// if thread is in waiting mode, but command
				// is not to resume a waiting thread
				thread = NULL;
			else	SuspendQ[type-2]->RemoveFocus();
		}
	}

	if( thread == NULL ){	// no this id!!
		DispatchMask = 0;
		return	ERR_BADID;
	}

	// resume it!
	thread->status = THREAD_READY;
	switch(type){
	 case THREAD_TIMECRITICAL: // reset table
		ReadyThread[priority>>2] |= Map[(priority&0x03)];
		ReadyGroup |= Map[(priority>>2)];
			break;
	 case THREAD_EVENTDRIVEN:
	 case THREAD_TIMESLICING:
		*ReadyQ[type-2] + thread;	// re-instert to Ready Queue
		if( thread->type == THREAD_TIMESLICING )
			thread->slice_left = thread->slice;
			// reset time slice
			break;
	}
	return ERR_NOERROR;
}

// Kernel API : GiveUpSlice
void far TauKernel :: GiveUpSlice()
{ // usable for time-slicing thread
	if( CurrentThreadType != THREAD_TIMESLICING )	return;
	DispatchMask = 1;
	CurrentThread[2]->slice_left = 1;
	DispatchMask = 0;
	asm int 0xff;
}

// Private Kernel API : TimeDispatch
int far TauKernel :: TimeDispatch()
{
	// Choose highest priority thread in ReadyThread
	if( CurrentThread[0] && CurrentThread[0]->status==THREAD_CURRENT )
		CurrentThread[0]->status = THREAD_READY;
	if( ReadyGroup ){	// There are some thread are at ready type
		unsigned priority = UnMap[ReadyGroup];
		priority = UnMap[ReadyThread[priority]] + (priority<<2) ;
		// Set this thread as current thread
		CurrentThread[0] = Time[priority];
		CurrentThread[0]->status = THREAD_CURRENT;
	}
	else
		return 0;
	return THREAD_TIMECRITICAL;
}

int far TauKernel :: EventDispatch()
{
	// find highest priority thread
	if( CurrentThread[1] )
		if(CurrentThread[1]->status == THREAD_CURRENT )
			CurrentThread[1]->status = THREAD_READY;
	CurrentThread[1] = NULL;
	CurrentThread[1] = Event();
	if( CurrentThread[1] )	CurrentThread[1]->status = THREAD_CURRENT;

	if( CurrentThread[1] )	return THREAD_EVENTDRIVEN;
	else					return 0;
}

int far TauKernel :: SliceDispatch()
{
	if( CurrentThread[2] && CurrentThread[2]->status == THREAD_CURRENT ){
			// current thread is present
		CurrentThread[2]->slice_left --;
		//if slice is over, change to another thread
		if( CurrentThread[2]->slice_left == 0){
			// reset slice
			CurrentThread[2]->slice_left = CurrentThread[2]->slice;
			CurrentThread[2]->status = THREAD_READY;
			CurrentThread[2] = (Thread*)CurrentThread[2]->next();
		}
	}
	else	// CurrentThread[2] == NULL
		CurrentThread[2] = Slice();	// choose 1st thread
	if(CurrentThread[2]){
		CurrentThread[2]->status = THREAD_CURRENT;
		return THREAD_TIMESLICING;
	}
	else					return 0;
}

/*
	CleanerThread has been moved to TaskMGR module, and re-named as
	CleanerTask. Please check TaskMGR.h, TaskMGR.cpp.
*/