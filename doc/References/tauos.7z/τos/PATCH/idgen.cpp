//***************************************************************
//	Idgen.cpp						*
//	Generating the task ID.					*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#include <assert.h>

//#include "u:\work\tau\patch\idgen.h"
#include "tauerr.h"

IDGenerator :: IDGenerator()
{
	/* Make sure IDRANGE will NOT greater than 1024 */
	assert(IDRANGE <= 1024);
	noFreeID = IDRANGE;
	CurrentID = 0;
	for(int i=0 ; i<IDRANGE; i++)
		IDArray[i].inUse = 0;
}

int IDGenerator :: GenerateID(unsigned& id)
{
	if( noFreeID == 0 ){	// no free ID in IDArray
		return ERR_NOFREEID;
	}

	while(1){
		/* if CurrentID == IDRANGE,
			 reset CurrentID to 0 */
		if( CurrentID == IDRANGE )		CurrentID = 0;
		if( !IDArray[CurrentID].inUse )	break;

		CurrentID ++;
	}

	IDArray[CurrentID].inUse =
			~IDArray[CurrentID].inUse; // set flag to 1
	id = CurrentID;		// return new id
	CurrentID ++;
	noFreeID --;
	return ERR_NOERROR;
}

void IDGenerator :: ReleaseID(unsigned id)
{
	/* Normally, id will not be greater than IDRANGE */
	/*
		assert( id < IDRAANGE);
	*/
	if( id < IDRANGE && IDArray[id].inUse ){
		IDArray[id].inUse =
				~IDArray[id].inUse; // set flag to 0
		noFreeID ++;
	}
}
/*
#include <iostream.h>
void main()
{
 IDGenerator	IDGen;
 unsigned		id;
	for(int i=0 ; i<5 ; i++)
		if(IDGen.GenerateID(id) == 0 )
			cout << id <<" ";

	IDGen.ReleaseID(0);
	IDGen.ReleaseID(2);
	IDGen.ReleaseID(5);

	cout << "\nFree ID : "<<IDGen.CountFreeID()<<" IDs are free\n";
	for(i=0 ; i<5 ; i++)
		if(IDGen.GenerateID(id) == 0 )
			cout << id <<" ";
		else
			cout << "error ";
}
*/