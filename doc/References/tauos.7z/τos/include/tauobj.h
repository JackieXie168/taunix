//***************************************************************
//	Tauobj.h						*
//	Base classes for the Tau-OS kernel.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __TAUOBJ_H__
#define __TAUOBJ_H__

class far TAUObj{
 public :
	virtual int isTAUObj()	{	return 1;	}
};

class far Container : public TAUObj{
 public :
	virtual int isContainer()	{	return 1;	}
};

class far Collection : public TAUObj{
 public :
	virtual int isCollection()	{	return 1;	}
};

class far Manager : public TAUObj{
 public :
	virtual int isManager()	{	return 1;	}
};

class far Device : public TAUObj{
 public:
	virtual int isDevice()	{	return 1;	}
	virtual int write(char data)	{	if(data);	return 1;	}
	virtual int read(char *data)	{	data = 0L;	return 0;	}
};

class far Message : public TAUObj{
 public:
	virtual int isMessage()	{	return 1;	}
};

#endif