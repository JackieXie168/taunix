//***************************************************************
//	Tauerr.h						*
//	The error code for the Tau-OS kernel.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __TAUERR_H__
#define __TAUERR_H__
enum err_code{
	ERR_NOERROR = 0,
	ERR_UNKNOWNTYPE,
	ERR_BADPRIORITY,
	ERR_BADID,
	ERR_TICKFULL,
	ERR_INCRITICAL,
	ERR_NOSPACE,
	ERR_SIGBUSY,
	ERR_SIGTIMEOUT,
	ERR_SIGEMPTY,
	ERR_PIPEFULL,
	ERR_PIPEEMPTY,
	ERR_PIPEBUSY,
	ERR_PORTBUSY,
	ERR_COMMBUSY,
	ERR_NOMESSAGE
};

#endif


