//***************************************************************
//	Taskmgr.h						*
//	the header file for the task manager of Tau-OS.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __TASKMGR_H__
#define __TASKMGR_H__

#include "tauobj.h"
// Error code definition
#include "tauerr.h"
typedef int APIRET;

void far EndTask();
// Task Manager definition
class far TaskMGR : public Manager{
 public:
	APIRET far CreateTimeTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio,unsigned period);
	APIRET far CreateEventTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio=8);
	APIRET far CreateSliceTask(unsigned &id,void far(*proc)(void far *arg),void far *arg,unsigned stack_size,unsigned prio=12);
	APIRET far KillTask(unsigned id);
	APIRET far SuspendTask(unsigned id);
	APIRET far ResumeTask(unsigned id);
	void 	 far GiveUpSlice()	{	Tau.GiveUpSlice();	}
};
#endif