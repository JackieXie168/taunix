//***************************************************************
//	Tpipe.h							*
//	The header file for PIPE communication.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __TPIPE_H__
#define __TPIPE_H__

#include "kernel.h"
#include <malloc.h>
template<class DATA> class far TPIPE : public Message {
 private:
    DATA        *pool;
    int       pool_size;
    int        head,tail;
    unsigned   count;
    unsigned   busy:1;
 public:
    TPIPE(int psize = 100);
    ~TPIPE();
    virtual int operator << (DATA input);
    virtual int operator >> (DATA &output);
};


template<class DATA> TPIPE<DATA> :: TPIPE(int psize=100)
{
    Tau.DispatchMask = 1;
    pool = (DATA far *)farmalloc(sizeof(DATA)*psize);
    busy = 1;
    Tau.DispatchMask = 0;

    if( pool == NULL ){
        pool_size = 0;
        return;
    }
    pool_size = psize;
    count = 0;
    head = 0;    tail = 0;
    busy = 0;
}

template<class DATA> TPIPE<DATA> :: ~TPIPE()
{
    Tau.DispatchMask = 1;
    farfree(pool);
    count = pool_size = 0;
    Tau.DispatchMask = 0;
}

template<class DATA> int far TPIPE<DATA> :: operator << (DATA input)
{
    if( count == pool_size )        return ERR_PIPEFULL;
    pool[tail] = input;
    tail++;
    count++;
    if( tail == pool_size )        tail = 0;
    return ERR_NOERROR;
}

template<class DATA> int far TPIPE<DATA> :: operator >> (DATA& output)
{
    if(!count)                return ERR_PIPEEMPTY;
    output = pool[head];
    head++;
    count--;
    if( head == pool_size )        head = 0;
    return ERR_NOERROR;
}
/*
void main()
{
 TPIPE<int>    intpipe(10);
 TPIPE<double>    dpipe(10);
    int a=0;
    intpipe << 10;
    intpipe >> a;
    cout<<"\nintpipe>>a->"<<a;
    double b;
    intpipe << 20;
    dpipe << 3.141592657;
    dpipe >> b;
    cout<<"\ndpipe>>b->"<<b;

}*/

#endif
