//***************************************************************
//	List.h							*
//	The header file for list and queue.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __LIST_H__
#define __LIST_H__
#include "tauobj.h"

#ifndef	NULL
#define	NULL	0L
#endif

class far _node : public Container{
 private:
	_node	*_next;
	_node 	*_prev;
 public:
	far _node()				{	_next = NULL;	_prev = NULL;	}
	_node *	next()			{	return _next;	}
	_node *	prev()			{	return _prev;	}
	void		next( _node *n)	{	_next = n;	}
	void      prev( _node *p)     {	_prev = p;	}
};

class far _list	: public Collection{
 private:
	_node * _head;
	_node * _focus;
 public:
	_list()
	{	_head = NULL;_focus = NULL;	}
	void insert(_node *node);
	_node *erase();
	int operator >> (int i);
	int operator << (int i);
	int is_empty()
	{
		if( _head )	return 0;
		else				return 1;
	}
	_node *toHead()
	{	_focus = _head;	return _focus;	}
	_node *focus()	{	return _focus;	}
	_node *head()	{	return _head;	}
 protected:
	void chgHead(_node *head)	{	_head =  head ;	}
};

class far _qItem : public _node {
 private:
	unsigned	prio;
 public:
				_qItem()	{	prio = 0;	}
	void		priority(unsigned p)	{	prio = p;		}
	unsigned priority()			{	return prio;	}
};

class far _queue : _list {
 public:
	 void 	operator + ( _qItem	*item );	// add an item
	_qItem * 	operator -- ();	// get 1st item, and remove it
	_qItem * 	first()			// get 1st item, but not remove it
	{	return (_qItem *)_list :: head();
	}
	_qItem * focus()
	{	return (_qItem *) _list :: focus();	}
	_qItem * toHead()	{	return (_qItem*) _list :: toHead();	}
	_qItem * remove_focus()
	{	return (_qItem *)_list :: erase();	}
	int operator << (int i)
	{	return _list :: operator << (i);	}
	int operator >> (int i)
	{	return _list :: operator >> (i);	}
	int is_empty()	{	return _list :: is_empty();	}
};
#endif