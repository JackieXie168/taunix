//***************************************************************
//	Kernel.h						*
//	The header file for the Tau-OS kernel.			*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __TAU_KERNEL_H__
#define __TAU_KERNEL_H__

#ifndef NULL
#define NULL    0L
#endif

#include <DOS.h>
#include "list.h"

// Definition : Thread type
#define THREAD_TIMECRITICAL    1
#define THREAD_EVENTDRIVEN     2
#define THREAD_TIMESLICING     3
#define THREAD_NONE            0

//Definition : Thread status
#define THREAD_READY      1
#define THREAD_CURRENT    2
#define THREAD_SUSPEND    3
#define THREAD_DELAY      4
#define THREAD_WAIT       5
#define THREAD_KILLING    6
#define THREAD_FREE       7


//Difinition : Error Message
#include "tauerr.h"

/* Declaration of Thread    */
class far Thread : public _qItem{
 public:
    void far (*StartAdd)(void far*arg);
    void far *Arg;
    unsigned SP,BP,SS;
    unsigned char far *Stack;
    unsigned StackSize;
    unsigned tid;
    int        slice,slice_left;
    int        status;
    int        type;

    void far setup(void far (*_start_add)(void far*arg),
        void far*arg,void far* _stack,unsigned stack_size,
        unsigned prio,int _type,unsigned rate,void far (*ret_add)(void));
};

/* Declaration of Thread Queue    */
class far ThreadQ : public _queue{
 private:
    unsigned no;
 public:
    ThreadQ()    {    no = 0;    }
//    ~ThreadQ();   // userd for debug
    unsigned operator+(Thread *t)
    {    _queue :: operator+((_qItem *) t);
        no ++;
        return no;
    }
    Thread* operator--()
    { --no; return (Thread*)_queue::operator--(); }
    Thread* operator()(){    return (Thread*)_queue :: first();    }
    Thread* Focus()    {    return (Thread*)_queue::focus();    }
    Thread* RemoveFocus()
    { --no; return (Thread*) _queue::remove_focus();    }
    unsigned Number()    {    return no;    }
    Thread* Get(unsigned id,int remove=1);
};

/* Tau-OS Kernel Object    */
class far TauKernel {
 private:
    char        ReadyGroup,ReadyThread[4];
    Thread    *Time[16];
    ThreadQ    TimeDelay;    // for delayed thread
    ThreadQ    Event,EventSuspend;    // for event-driven thread
    ThreadQ    Slice,SliceSuspend;    // for slice-sharing thread
    ThreadQ    *ReadyQ[2],*SuspendQ[2];
    ThreadQ    DeadQ;
    //    0 for Event, 1 for Slice
    Thread    *CurrentThread[3];    // record of current thread
    //        0    1    2
    //       Time Event Slice
    unsigned    CurrentThreadType:2;

    unsigned     SP,BP,SS;
    int          FpuFlag;        // indicate whether an FPU on your system
    unsigned  StartFlag:1;
    void far (*TickISR)    ();
    unsigned long    TickCounter;
    unsigned         ThreadCount;

    void interrupt (*oldInt08h)(...);
    void interrupt (*oldIntFEh)(...);
    void interrupt (*oldIntFFh)(...);
    int     far TimeDispatch();
    int     far EventDispatch();
    int     far SliceDispatch();

 public:
    unsigned  DispatchMask:1;
    unsigned  ShutDown:1;

    far TauKernel();
    far ~TauKernel();
    int    far CreateThread(Thread *th);
    int     far KillThread(unsigned id);
    Thread* ReturnDeadThread();
    int    far SuspendThread(unsigned id,int wait=0,int ToDelayQ=0);
    int     far ResumeThread(unsigned id,int wait=0);
    void  far GiveUpSlice();

    unsigned far CurrentThreadID()
    {    return CurrentThread[CurrentThreadType-1]->tid ;    }

    int    far ChangePriority(unsigned id,int type,int new_prio);
    void far Start(unsigned tick_rate=0);

    int    far SetTickISR(void far (*tick_isr)()    )
    {    if( TickISR )    return    ERR_TICKFULL;
        TickISR = tick_isr;
        return    ERR_NOERROR;
    }
    unsigned long far GetTime()    {    return TickCounter;    }

    unsigned FPU_type()    {    return FpuFlag;    }
    friend void far interrupt ClockISR(...);    // Clock ISR
    friend void far interrupt CTXTSW(...);    // for context switch not within TickISR

};

// Globle variables declaration
extern far TauKernel    Tau;
int FPUTest(void);
#define SWITCH_CONTEXT        Tau.DispatchMask=0;asm int 0xff
#define MaskDispatcher          Tau.DispatchMask = 1
#define ReleaseDispatcher  Tau.DispatchMask = 0
#define DispatcherMask        Tau.DispatchMask


#endif
