//***************************************************************
//	Comm.h							*
//	The header file for Tau-OS's communication manager.	*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __COMM_H__
#define __COMM_H__

#include "kernel.h"
#include "semevent.h"

class far MSGPack : _node,public Message{
 private:
    unsigned far sign;  // sign of sender
 public:
    MSGPack()    {    sign = Tau.CurrentThreadID();    }
    unsigned far MSGID;         // message ID
    unsigned far Receiver;      // message receiver
    unsigned Sender()    { return sign;    }
 friend class far mbox;
};

class far mbox : _list{
 public:
    ~mbox();
    int is_empty()    {    return _list :: is_empty();    }
    void far put(MSGPack *mpack);
    MSGPack far *get();
};

class far PORT : _qItem,public Message{
 private:
    mbox far 	mail_list;
    EVENT	msg;
    int far 	PutMessage(MSGPack *mpack);
    unsigned   inWait:1;
 public:
    PORT();
    ~PORT();
    int far hasMSG();
    unsigned PORTID()	{ return priority();	}
    MSGPack * GetMessage(int time_out=0);
 friend class far COMMGR;
};


class far COMMGR : public Manager,public Message{
 private:
    _queue PortList;
    void far RegisterPort(PORT *p);
    void far DeletePort();
 public:
    int far operator << (MSGPack *mpack);
 friend class PORT;
};

extern far COMMGR COMM;
#endif
