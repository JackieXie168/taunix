//***************************************************************
//	Tauos.h							*
//	The include file for Tau-OS application programs.	*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __TAUOS_H__
#define __TAUOS_H__

#include "tauerr.h"
#include "tauobj.h"
#include "list.h"
#include "kernel.h"
#include "taskmgr.h"
#include "semevent.h"
#include "comm.h"
#include "tpipe.h"

// Manager declaration
extern far TauKernel	Tau;
extern far TaskMGR		Task;
extern far COMMGR		COMM;

// Globle semaphore declaration
extern far SEM				video;
#define VIDEO_Begin			if(video.pend()==ERR_NOERROR){
#define VIDEO_Pend(time_out)	if(video.pend(time_out)==ERR_NOERROR){
#define VIDEO_End			video.post();}

#define IntCritical_Begin	if(!Tau.DispatchMask){
#define IntCritical_End		}

// Macro declration
// Kernel
#define SWITCH_CONTEXT		Tau.DispatchMask=0;asm int 0xff
#define MaskDispatcher	  	Tau.DispatchMask = 1
#define ReleaseDispatcher  	Tau.DispatchMask = 0
#define DispatcherMask		Tau.DispatchMask
#define PTID				Tau.CurrentThreadID()
#define TauStart			Tau.Start
#define TauShutDown			Tau.ShutDown=1

// Task Manager
#define TauCreateTimeTask	Task.CreateTimeTask
#define TauCreateEventTask	Task.CreateEventTask
#define TauCreateSliceTask	Task.CreateSliceTask
#define TauSetTickISR		Tau.SetTickISR
#define TauKillTask			Task.KillTask
#define TauSuspendTask		Task.SuspendTask
#define TauResumeTask		Task.ResumeTask
#define TauGiveUpSlice		Task.GiveUpSlice
#define TASK                  void far
#define ARG				void far *

// Time Management
#define TauTimeWait()			Task.SuspendTask(PTID)
#define TauTimeDelay(delay)	{Tau.SuspendThread(PTID,0,delay);SWITCH_CONTEXT;}
#define TauGetTime()  		Tau.GetTime()

#endif