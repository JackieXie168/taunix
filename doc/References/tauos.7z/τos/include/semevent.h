//***************************************************************
//	Semevent.h						*
//	The header file for semaphore and event.		*
//								*
//	Author:							*
//		Yang-Tau Ying, July 1995			*
//								*
//	Copyright(c) 1995, Jwusheng Hu and Yang-Tau Ying	*
//								*
//***************************************************************

#ifndef __SEMEVENT_H__
#define __SEMEVENT_H__

#include "list.h"
#include "tauerr.h"

class far sigItem : public _node{
	unsigned id;
	friend sigItem* findfree(sigItem *pool,unsigned size);
	friend class far SIG;
	public:
		sigItem()	{id = 0;}
};

class far SIG : public Message{
 private:
	_list waitL;
	sigItem far *pool;
	unsigned pool_size;
 public:
	SIG(unsigned size = 10 );
	~SIG();
	virtual int far pend(unsigned time_out=0);
	virtual int far post();
};

class far SEM : public SIG{
 private:
	int S;
 public:
	SEM(unsigned size=10) : SIG(size){S=1;}
	int far pend(unsigned time_out=0);
	int far post();
};

class far EVENT : SIG{
 private:
	unsigned trig:1;
 public:
	EVENT(unsigned size=1) : SIG(size){trig = 0;}
	int far pend(unsigned time_out=0);
	int far post();
};

#define SIG_NOWAIT		0
#define SIG_WAIT		1
#define SIG_TIMEOUT		2

#endif